export class Students {
    name: '';
    contact: '';
    address: '';
    id: random = Math.floor(Math.random() * (999999 - 100000)) + 100000;
    
}